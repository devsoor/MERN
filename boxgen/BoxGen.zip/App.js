import React from 'react';
import './App.css';
import BoxGen from './Box/BoxGen';

function App() {
  return (
    <div className="App">
      <BoxGen/>
    </div>
  );
}

export default App;
