import React, {useState, useEffect} from 'react';
import {Container, Row, Col, Form, Input, Label, Card, CardTitle, FormGroup, CardBody, Button} from 'reactstrap';
import axios from 'axios';

const ProductForm = (props) => {
    const [state, setState] = useState({
        title: null,
        price: null,
        description: null
    });

    const handleChange = (e) => {
        setState({...state, [e.target.name]: e.target.value});
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        const {title, price, description} = state;
        axios.post('http://localhost:8000/api/product', {title, price, description})
            .then(res=>console.log("Response: ",res))
            .catch(err=>console.log("Error: ", err))
    }

    return (
        <Container>
            <CardBody>
            <Row>
                <Col sm="12" md={{ size: 6, offset: 3 }}>>
                    <Form className="form-horizontal" onSubmit={handleSubmit}>
                        <CardTitle className="bg-info border-bottom p-3 mb-0 text-white">Product Manager</CardTitle>
                        <FormGroup row>
                                <Label for="title">Title:</Label> 
                                <Input type="text" id="title" name="title" onChange={handleChange}/>
                        </FormGroup>
                        <FormGroup row>
                                <Label for="price">Price: </Label> 
                                <Input type="text" id="price" name="price" onChange={handleChange}/>
                        </FormGroup >
                        <FormGroup row>
                                <Label for="description">Description: </Label> 
                                <Input type="text" id="description" name="description" onChange={handleChange}/>
                        </FormGroup>
                        <Button type="submit" color="danger">Create</Button>
                    </Form>
                </Col>
                </Row>
                </CardBody>
        </Container>
    );
};

export default ProductForm;