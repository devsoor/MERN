import React, {useEffect, useState} from 'react';
import {Container, Row, Col, Form, Input, Label, CardTitle, FormGroup, CardBody, Button} from 'reactstrap';
import axios from 'axios';
import { Link } from '@reach/router';


const Update = (props) => {
    const [state, setState] = useState({
        title: '',
        price: '',
        description: ''
    });
    const [loaded, setLoaded] = useState(false);

    useEffect(() => {
        axios.get('http://localhost:8000/api/product/' + props.id)
        .then(res => {
            setState(res.data);
            setLoaded(true);
            })
            .catch(err => {
                console.log("Error getting product. ", err);
                setLoaded(false);
            })
    }, [loaded])

    const handleChange = (e) => {
        const {name, value} = e.target;
        setState({...state, [name]: value});
    }
    const handleUpdateSubmit = (e) => {
        e.preventDefault();
        const {title, price, description} = state;

        axios.put('http://localhost:8000/api/product/'+ props.id, {title, price, description})
            .then(res=>console.log("Response: ",res))
            .catch(err=>console.log("Error: ", err))
    }   

    return (
        <Container>
            <CardBody>
                {
                    loaded && <Row>
                        <Col sm="12" md={{ size: 6, offset: 3 }}>
                            <CardTitle className="bg-info border-bottom p-3 mb-0 text-white">Update Product</CardTitle>
                            <Form className="form-horizontal" onSubmit={handleUpdateSubmit}>
                                <FormGroup row>
                                        <Label for="title">Title:</Label> 
                                        <Input type="text" id="title" name="title" value={state.title} onChange={handleChange}/>
                                </FormGroup>
                                <FormGroup row>
                                        <Label for="price">Price: </Label> 
                                        <Input type="number" id="price" name="price" value={state.price} onChange={handleChange}/>
                                </FormGroup >
                                <FormGroup row>
                                        <Label for="description">Description: </Label> 
                                        <Input type="text" id="description" name="description" value={state.description} onChange={handleChange}/>
                                </FormGroup>
                                <Button type="submit" color="danger">Update</Button>
                            </Form>
                        </Col>
                        <Link to="/">Home</Link>
                    </Row>
                }
            </CardBody>
        </Container>
    )

}

export default Update;