import React, {useState, useEffect} from 'react';
import {Jumbotron, Row, Col, Button} from 'reactstrap';
import axios from 'axios';
import { Link, navigate } from '@reach/router';


const Detail = (props) => {
    const [product, setProduct] = useState({});
    const deleteProduct = (delId) => {
        axios.delete('http://localhost:8000/api/product/' + delId)
        .then(res => {
                props.onRemoveProduct(delId);
            })
        .catch(err => {
            console.log("Error getting product. ", err);
        })
        .finally(navigate('/'))
    }
    useEffect(() => {
        axios.get("http://localhost:8000/api/product/" + props.id)
            .then(res => {
                setProduct({...res.data});
            })
    }, [])
    return (
        <div>
            <Jumbotron>
                <h3 className="display-3">{product.title}</h3>
                <p className="lead">Price: {product.price}</p>
                <p className="lead">Description: {product.description}</p>
            <Row>
                <Col>
                    <Link to={"/product/" + props.id + "/edit"}>
                        Edit
                    </Link>
                </Col>
                <Col>
                    <Button className="btn-sm btn-danger" onClick={(e) => {deleteProduct(product._id)}}>Delete</Button>
                </Col>
            </Row>
            </Jumbotron>
        </div>
    )
}

export default Detail;