import React from 'react';
import { Link } from '@reach/router';
import { Col } from 'reactstrap';

const ProductList = (props) => {
    return (
        <div>
            {props.products.map((product, i) => {
                return <Col key={i}><Link to={'product/' + product._id} >{product.title}</Link></Col>
            })}
        </div>
    )
};

export default ProductList;