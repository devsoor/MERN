import React, {useState, useEffect} from 'react';
import {Jumbotron} from 'reactstrap';
import axios from 'axios';

const Detail = (props) => {
    const [product, setProduct] = useState({});
    console.log("Detail: id = ", props.id)
    useEffect(() => {
        axios.get("http://localhost:8000/api/product/" + props.id)
            .then(res => {
                console.log("res.data = ", res.data)
                setProduct({...res.data});
            })
    }, [])
    return (
        <div>
            <Jumbotron>
                <h3 className="display-3">{product.title}</h3>
                <p className="lead">Price: {product.price}</p>
                <p className="lead">Description: {product.description}</p>
            </Jumbotron>
        </div>
    )
}

export default Detail;