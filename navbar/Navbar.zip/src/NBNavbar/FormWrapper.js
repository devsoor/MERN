import React from 'react';
import NBForm from './Form';

const FormWrapper = (props) => {
    
    return (
        <div>
            <NBForm/>
        </div>
    )
}

export default FormWrapper;

