import React from 'react';
import './App.css';
import Wrapper from './NBNavbar/Wrapper';
import NBNavbar from './NBNavbar/NBNavbar';
import FormWrapper from './NBNavbar/FormWrapper';

function App() {
  return (
      <Wrapper>
            <NBNavbar/>
            <FormWrapper/>
      </Wrapper>
  );
}

export default App;
